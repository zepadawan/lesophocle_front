
export interface User {
  id?: number,
  firstname?: string,
  lastname?: string,
  username?: String;
  sexe?: string,
  email: string,
  password: string,
  dateBirth?: string,
  role?: string,
}