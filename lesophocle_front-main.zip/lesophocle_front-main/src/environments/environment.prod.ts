export const environment = {
  production: true,
  api: 'https://lesophocle.com:8082/',
  api_image: 'https://lesophocle.com:8082/public/images/',

}
