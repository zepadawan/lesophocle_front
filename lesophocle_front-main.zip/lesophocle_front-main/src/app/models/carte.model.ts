export class Carte {
  id?: number;
  libelle?: string;
}
