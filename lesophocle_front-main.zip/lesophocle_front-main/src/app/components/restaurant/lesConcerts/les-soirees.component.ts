import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'node-les-soirees',
  templateUrl: './les-soirees.component.html',
  styleUrls: ['./les-soirees.component.css']
})
export class LesSoireesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
