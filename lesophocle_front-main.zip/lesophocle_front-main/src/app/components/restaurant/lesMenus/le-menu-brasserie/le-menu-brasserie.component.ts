import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'node-le-menu-brasserie',
  templateUrl: './le-menu-brasserie.component.html',
  styleUrls: ['./le-menu-brasserie.component.css']
})
export class LeMenuBrasserieComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
