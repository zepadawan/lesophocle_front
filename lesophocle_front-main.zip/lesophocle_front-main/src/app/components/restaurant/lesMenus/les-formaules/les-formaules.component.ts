import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'node-les-formaules',
  templateUrl: './les-formaules.component.html',
  styleUrls: ['./les-formaules.component.css']
})
export class LesFormaulesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
