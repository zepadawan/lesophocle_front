import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'node-les-boissons',
  templateUrl: './les-boissons.component.html',
  styleUrls: ['./les-boissons.component.css']
})
export class LesBoissonsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
