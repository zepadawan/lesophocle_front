export class Categorie {
  id?: number;
  libelle?: string;
}
