export class Plat {
  id?: number;
  libelle?: string;
  id_categorie?: number;
  prix?: string;
  ordre?: number;
  poids_dimension?: string;
  description?: string;
  sous_titre?: string;
  nom_image?: string
}
