import { Plat } from "./plat-modele";

export class Item {
  tableau: Plat;
  quantity: number;

}

