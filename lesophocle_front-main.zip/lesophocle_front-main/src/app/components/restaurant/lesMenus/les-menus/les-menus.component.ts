import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'node-les-menus',
  templateUrl: './les-menus.component.html',
  styleUrls: ['./les-menus.component.css']
})
export class LesMenusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
