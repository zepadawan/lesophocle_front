export interface Result {
  status: number,
  message: string,
  result,
  time: string,
  args: any,
  token: string,
}
