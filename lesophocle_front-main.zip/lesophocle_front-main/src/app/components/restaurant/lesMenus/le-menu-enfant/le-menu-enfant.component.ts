import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'node-le-menu-enfant',
  templateUrl: './le-menu-enfant.component.html',
  styleUrls: ['./le-menu-enfant.component.css']
})
export class LeMenuEnfantComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
