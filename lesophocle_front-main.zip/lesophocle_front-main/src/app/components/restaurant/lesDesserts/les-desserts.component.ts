import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'node-les-desserts',
  templateUrl: './les-desserts.component.html',
  styleUrls: ['./les-desserts.component.css']
})
export class LesDessertsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
