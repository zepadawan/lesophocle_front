import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'node-le-menu-pizza',
  templateUrl: './le-menu-pizza.component.html',
  styleUrls: ['./le-menu-pizza.component.css']
})
export class LeMenuPizzaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
