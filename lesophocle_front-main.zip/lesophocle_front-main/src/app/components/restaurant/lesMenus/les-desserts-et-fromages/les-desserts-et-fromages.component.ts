import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'node-les-desserts-et-fromages',
  templateUrl: './les-desserts-et-fromages.component.html',
  styleUrls: ['./les-desserts-et-fromages.component.css']
})
export class LesDessertsEtFromagesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
