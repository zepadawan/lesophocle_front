import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'node-edit-categorie',
  templateUrl: './edit-categorie.component.html',
  styleUrls: ['./edit-categorie.component.css']
})
export class EditCategorieComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
