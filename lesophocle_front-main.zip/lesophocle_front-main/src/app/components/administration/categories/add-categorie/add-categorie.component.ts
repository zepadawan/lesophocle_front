import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'node-add-categorie',
  templateUrl: './add-categorie.component.html',
  styleUrls: ['./add-categorie.component.css']
})
export class AddCategorieComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
