import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'node-les-soirees-privees',
  templateUrl: './les-soirees-privees.component.html',
  styleUrls: ['./les-soirees-privees.component.css']
})
export class LesSoireesPriveesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
